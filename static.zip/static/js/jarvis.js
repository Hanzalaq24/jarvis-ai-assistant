// JARVIS Holographic Interface JavaScript
class JarvisInterface {
    constructor() {
        this.isListening = false;
        this.isWakeWordListening = false;
        this.recognition = null;
        this.wakeWordRecognition = null;
        this.synthesis = window.speechSynthesis;
        this.currentResponse = '';
        this.wakeWords = ['hey jarvis', 'jarvis', 'हे जार्विस', 'જાર્વિસ'];
        
        this.initializeElements();
        this.initializeSpeechRecognition();
        this.initializeWakeWordDetection();
        this.initializeEventListeners();
        this.createHolographicEffects();
        this.createAdvancedFeatures();
        this.startStatusUpdates();
        this.startSystemMonitoring();
        this.startWakeWordListening();
        this.playStartupSequence();
    }

    initializeElements() {
        this.voiceInput = document.getElementById('voiceInput');
        this.responseDisplay = document.getElementById('responseDisplay');
        this.listenBtn = document.getElementById('listenBtn');
        this.sendBtn = document.getElementById('sendBtn');
        this.typingIndicator = document.getElementById('typingIndicator');
        this.statusDot = document.querySelector('.status-dot');
        this.statusText = document.getElementById('statusText');
    }

    initializeSpeechRecognition() {
        this.currentLanguage = 'en-US';
        this.supportedLanguages = {
            'en-US': 'English',
            'hi-IN': 'हिंदी',
            'gu-IN': 'ગુજરાતી'
        };
        
        if ('webkitSpeechRecognition' in window) {
            // Main recognition for commands
            this.recognition = new webkitSpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = this.currentLanguage;

            this.recognition.onstart = () => {
                this.isListening = true;
                this.updateListenButton();
                this.updateStatus('Listening...', 'listening');
                this.addVoiceVisualization();
            };

            this.recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                this.voiceInput.value = transcript;
                this.processCommand(transcript);
            };

            this.recognition.onerror = (event) => {
                console.error('Speech recognition error:', event.error);
                this.updateStatus('Error: ' + event.error, 'error');
                this.isListening = false;
                this.updateListenButton();
                this.removeVoiceVisualization();
            };

            this.recognition.onend = () => {
                this.isListening = false;
                this.updateListenButton();
                this.updateStatus('Ready', 'ready');
                this.removeVoiceVisualization();
                // Restart wake word listening after command processing
                setTimeout(() => this.startWakeWordListening(), 1000);
            };
        } else {
            console.warn('Speech recognition not supported');
            this.listenBtn.disabled = true;
            this.listenBtn.textContent = 'Not Supported';
        }
    }

    initializeWakeWordDetection() {
        if ('webkitSpeechRecognition' in window) {
            // Separate recognition for wake word detection
            this.wakeWordRecognition = new webkitSpeechRecognition();
            this.wakeWordRecognition.continuous = true;
            this.wakeWordRecognition.interimResults = true;
            this.wakeWordRecognition.lang = this.currentLanguage;

            this.wakeWordRecognition.onresult = (event) => {
                const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase();
                
                // Check for wake words
                for (let wakeWord of this.wakeWords) {
                    if (transcript.includes(wakeWord.toLowerCase())) {
                        this.onWakeWordDetected(transcript);
                        break;
                    }
                }
            };

            this.wakeWordRecognition.onerror = (event) => {
                if (event.error !== 'no-speech') {
                    console.error('Wake word recognition error:', event.error);
                }
                // Restart wake word listening after error
                setTimeout(() => this.startWakeWordListening(), 2000);
            };

            this.wakeWordRecognition.onend = () => {
                if (this.isWakeWordListening) {
                    // Restart wake word listening if it should be active
                    setTimeout(() => this.startWakeWordListening(), 100);
                }
            };
        }
    }

    initializeEventListeners() {
        this.listenBtn.addEventListener('click', () => this.toggleListening());
        this.sendBtn.addEventListener('click', () => this.sendCommand());
        
        this.voiceInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendCommand();
            }
        });

        // Quick command buttons
        document.querySelectorAll('.quick-cmd').forEach(cmd => {
            cmd.addEventListener('click', () => {
                const command = cmd.dataset.command;
                this.voiceInput.value = command;
                
                // Special handling for photo capture
                if (command === 'take photo') {
                    this.capturePhoto();
                } else {
                    this.processCommand(command);
                }
            });
        });

        // Arc reactor click effect
        document.querySelector('.arc-reactor').addEventListener('click', () => {
            this.playStartupSound();
            this.showWelcomeMessage();
        });

        // Language selector
        this.createLanguageSelector();
        
        // Wake word toggle
        this.createWakeWordToggle();
    }

    toggleListening() {
        if (this.isListening) {
            this.recognition.stop();
        } else {
            this.recognition.start();
        }
    }

    updateListenButton() {
        if (this.isListening) {
            this.listenBtn.innerHTML = '<i class="fas fa-stop"></i> Stop Listening';
            this.listenBtn.classList.add('listening');
        } else {
            this.listenBtn.innerHTML = '<i class="fas fa-microphone"></i> Voice Command';
            this.listenBtn.classList.remove('listening');
        }
    }

    async sendCommand() {
        const command = this.voiceInput.value.trim();
        if (!command) return;

        this.processCommand(command);
    }

    async processCommand(command) {
        this.showTypingIndicator();
        this.updateStatus('Processing...', 'processing');
        
        // Add to command history
        this.addToHistory(command);
        
        // Show notification
        this.showNotification('Command Received', `Processing: "${command.substring(0, 30)}${command.length > 30 ? '...' : ''}"`, 2000);

        // Check for photo capture commands
        const photoCommands = ['take photo', 'capture photo', 'take picture', 'capture picture', 'photo', 'फोटो खींचो', 'ફોટો લો'];
        if (photoCommands.some(cmd => command.toLowerCase().includes(cmd))) {
            this.hideTypingIndicator();
            this.capturePhoto();
            return;
        }

        // Check for screenshot commands
        const screenshotCommands = ['take screenshot', 'capture screen', 'screenshot', 'screen shot', 'स्क्रीनशॉट', 'સ્ક્રીનશોટ'];
        if (screenshotCommands.some(cmd => command.toLowerCase().includes(cmd))) {
            this.hideTypingIndicator();
            this.takeScreenshot();
            return;
        }

        // Check for file operation commands
        const fileOperationCommands = [
            'create file', 'make file', 'new file',
            'create folder', 'make folder', 'new folder',
            'delete file', 'remove file', 'delete folder', 'remove folder',
            'rename file', 'rename folder', 'rename',
            'find file', 'search file', 'locate file',
            'open file', 'launch file', 'run file',
            'restore file', 'restore', 'undelete file', 'recover file',
            'copy file', 'copy folder', 'move file', 'move folder'
        ];
        
        if (fileOperationCommands.some(cmd => command.toLowerCase().includes(cmd))) {
            this.hideTypingIndicator();
            
            // Show appropriate processing message based on operation
            if (command.toLowerCase().includes('create')) {
                this.displayResponse("📝 Creating file...");
            } else if (command.toLowerCase().includes('delete') || command.toLowerCase().includes('remove')) {
                this.displayResponse("🗑️ Processing delete operation...");
            } else if (command.toLowerCase().includes('open') || command.toLowerCase().includes('launch')) {
                this.displayResponse("📂 Opening file...");
            } else if (command.toLowerCase().includes('restore') || command.toLowerCase().includes('recover')) {
                this.displayResponse("♻️ Restoring file from trash...");
            } else if (command.toLowerCase().includes('find') || command.toLowerCase().includes('search')) {
                this.displayResponse("🔍 Searching for file...");
            } else {
                this.displayResponse("🔄 Processing file operation...");
            }
            
            // Let the backend handle file operations
            this.processCommand(command);
            return;
        }

        // Check for song recognition commands
        const songCommands = ['listen to me sing', 'i will sing', 'let me sing', 'recognize this song', 'what song is this'];
        if (songCommands.some(cmd => command.toLowerCase().includes(cmd))) {
            this.hideTypingIndicator();
            this.startSongRecognition();
            return;
        }

        // Check for song lyrics recognition
        const lyricsCommands = ['the song goes', 'song with lyrics', 'play song', 'find song'];
        if (lyricsCommands.some(cmd => command.toLowerCase().includes(cmd))) {
            // Extract lyrics from command
            let lyrics = command;
            for (const cmd of lyricsCommands) {
                if (command.toLowerCase().includes(cmd)) {
                    lyrics = command.substring(command.toLowerCase().indexOf(cmd) + cmd.length).trim();
                    break;
                }
            }
            
            if (lyrics && lyrics.length > 3) {
                this.hideTypingIndicator();
                this.recognizeSongFromLyrics(lyrics);
                return;
            }
        }

        try {
            const response = await fetch('/api/command', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ command: command })
            });

            const data = await response.json();
            this.displayResponse(data.response);
            this.speakResponse(data.response, data.language);
            this.updateStatus('Ready', 'ready');
            
            // Show success notification
            this.showNotification('Command Completed', 'Task executed successfully', 2000);
            
            // Update language selector if language was detected
            if (data.language) {
                this.updateLanguageFromDetection(data.language);
            }
        } catch (error) {
            console.error('Error:', error);
            this.displayResponse('Sorry, I encountered an error processing your command.');
            this.updateStatus('Error', 'error');
            this.showNotification('Error', 'Failed to process command', 3000);
        }

        this.hideTypingIndicator();
        this.voiceInput.value = '';
    }

    displayResponse(text) {
        this.currentResponse = text;
        const responseText = document.getElementById('responseText');
        responseText.textContent = '';
        
        // Typewriter effect
        let i = 0;
        const typeWriter = () => {
            if (i < text.length) {
                responseText.textContent += text.charAt(i);
                i++;
                setTimeout(typeWriter, 30);
            }
        };
        typeWriter();

        // Add glow effect
        this.responseDisplay.classList.add('response-glow');
        setTimeout(() => {
            this.responseDisplay.classList.remove('response-glow');
        }, 2000);
    }

    async speakResponse(text, language = 'en', retryCount = 0) {
        // Clean and validate text before sending
        if (!text || typeof text !== 'string') {
            console.warn('Invalid text for TTS:', text);
            return;
        }
        
        // Clean the text
        const cleanedText = text.trim().replace(/[^\x00-\x7F]/g, '').replace(/\s+/g, ' ');
        if (!cleanedText) {
            console.warn('Empty text after cleaning for TTS');
            return;
        }
        
        // Limit text length to prevent issues
        const maxLength = 500;
        const finalText = cleanedText.length > maxLength ? 
            cleanedText.substring(0, maxLength) + "..." : cleanedText;
        
        try {
            const response = await fetch('/api/speak', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    text: finalText,
                    language: language 
                }),
                timeout: 10000 // 10 second timeout
            });
            
            const result = await response.json();
            
            if (result.status === 'error') {
                console.error('TTS Server Error:', result.message);
                // Try fallback TTS if available
                this.fallbackTTS(finalText);
            } else {
                console.log('TTS Success:', result);
            }
            
        } catch (error) {
            console.error('TTS Network Error:', error);
            
            // Retry logic for network errors
            if (retryCount < 2) {
                console.log(`Retrying TTS (attempt ${retryCount + 1})`);
                setTimeout(() => {
                    this.speakResponse(text, language, retryCount + 1);
                }, 1000);
            } else {
                // Try fallback TTS after retries
                this.fallbackTTS(finalText);
            }
        }
    }
    
    cleanTextForTTS(text) {
        if (!text || typeof text !== 'string') return '';
        
        // Remove HTML tags
        let cleaned = text.replace(/<[^>]*>/g, '');
        
        // Remove problematic characters that cause garbled speech
        cleaned = cleaned.replace(/[^\w\s.,!?;:\-'"()]/g, ' ');
        
        // Fix multiple spaces
        cleaned = cleaned.replace(/\s+/g, ' ').trim();
        
        // Limit length to prevent TTS overload
        if (cleaned.length > 400) {
            cleaned = cleaned.substring(0, 400) + '...';
        }
        
        return cleaned;
    }

    fallbackTTS(text) {
        // Fallback to browser's built-in speech synthesis
        if ('speechSynthesis' in window) {
            try {
                // Cancel any ongoing speech
                window.speechSynthesis.cancel();
                
                // Clean the text first
                const cleanedText = this.cleanTextForTTS(text);
                
                if (!cleanedText) {
                    console.warn('No valid text to speak');
                    return;
                }
                
                const utterance = new SpeechSynthesisUtterance(cleanedText);
                utterance.rate = 0.85;  // Slower for clarity
                utterance.pitch = 1.0;
                utterance.volume = 0.7;
                
                // Better voice selection
                const setVoiceAndSpeak = () => {
                    const voices = window.speechSynthesis.getVoices();
                    
                    // Preferred voices for better quality
                    const preferredVoices = ['Alex', 'Samantha', 'Victoria', 'Daniel', 'Karen'];
                    let selectedVoice = null;
                    
                    // Try preferred voices first
                    for (const preferred of preferredVoices) {
                        selectedVoice = voices.find(voice => 
                            voice.name.includes(preferred) && voice.lang.startsWith('en')
                        );
                        if (selectedVoice) break;
                    }
                    
                    // Fallback to any English voice
                    if (!selectedVoice) {
                        selectedVoice = voices.find(voice => voice.lang.startsWith('en'));
                    }
                    
                    if (selectedVoice) {
                        utterance.voice = selectedVoice;
                        console.log(`🔊 Using TTS voice: ${selectedVoice.name}`);
                    }
                    
                    utterance.onstart = () => {
                        console.log('✅ TTS started successfully');
                    };
                    
                    utterance.onend = () => {
                        console.log('✅ TTS completed');
                    };
                    
                    utterance.onerror = (event) => {
                        console.error('❌ Fallback TTS Error:', event.error);
                        this.showNotification('TTS Error', 'Speech synthesis failed', 3000);
                    };
                    
                    window.speechSynthesis.speak(utterance);
                };
                
                // Handle voice loading
                if (window.speechSynthesis.getVoices().length > 0) {
                    setVoiceAndSpeak();
                } else {
                    window.speechSynthesis.onvoiceschanged = setVoiceAndSpeak;
                }
                
            } catch (error) {
                console.error('❌ Fallback TTS failed:', error);
                this.showNotification('TTS Error', 'Speech synthesis unavailable', 3000);
            }
        } else {
            console.warn('⚠️ No TTS available - text would be:', text);
            this.showNotification('No TTS', 'Speech synthesis not supported', 3000);
        }
    }

    showTypingIndicator() {
        this.typingIndicator.style.display = 'flex';
        document.getElementById('responseText').style.display = 'none';
    }

    hideTypingIndicator() {
        this.typingIndicator.style.display = 'none';
        document.getElementById('responseText').style.display = 'block';
    }

    updateStatus(text, type) {
        this.statusText.textContent = text;
        this.statusDot.className = 'status-dot';
        
        switch(type) {
            case 'listening':
                this.statusDot.style.background = '#ffaa00';
                this.statusDot.style.boxShadow = '0 0 10px #ffaa00';
                break;
            case 'processing':
                this.statusDot.style.background = '#4da6ff';
                this.statusDot.style.boxShadow = '0 0 10px #4da6ff';
                break;
            case 'error':
                this.statusDot.style.background = '#ff4444';
                this.statusDot.style.boxShadow = '0 0 10px #ff4444';
                break;
            default:
                this.statusDot.style.background = '#00ff88';
                this.statusDot.style.boxShadow = '0 0 10px #00ff88';
        }
    }

    addVoiceVisualization() {
        const reactor = document.querySelector('.arc-reactor');
        reactor.classList.add('listening-pulse');
        this.showVoiceSpectrum();
    }

    removeVoiceVisualization() {
        const reactor = document.querySelector('.arc-reactor');
        reactor.classList.remove('listening-pulse');
        this.hideVoiceSpectrum();
    }

    createParticles() {
        const particlesContainer = document.createElement('div');
        particlesContainer.className = 'particles';
        document.body.appendChild(particlesContainer);

        setInterval(() => {
            if (Math.random() < 0.3) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDuration = (Math.random() * 3 + 3) + 's';
                particle.style.opacity = Math.random() * 0.5 + 0.2;
                
                particlesContainer.appendChild(particle);
                
                setTimeout(() => {
                    particle.remove();
                }, 6000);
            }
        }, 200);
    }

    startStatusUpdates() {
        setInterval(() => {
            const now = new Date();
            const time = now.toLocaleTimeString();
            const dateTime = now.toLocaleString();
            
            // Update time displays
            const currentTime = document.getElementById('currentTime');
            if (currentTime) {
                currentTime.textContent = time;
            }
            
            const currentDateTime = document.getElementById('currentDateTime');
            if (currentDateTime) {
                currentDateTime.textContent = dateTime;
            }
        }, 1000);
    }

    playStartupSound() {
        // Create a simple beep sound
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.3);
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.3);
    }

    showWelcomeMessage() {
        const welcomeMessages = [
            "JARVIS online, sir. All systems operational.",
            "Good to see you again, sir. How may I assist you today?",
            "Systems initialized and ready for your commands, sir.",
            "Welcome back, sir. All systems are functioning within normal parameters.",
            "At your service, sir. What can I do for you today?"
        ];
        
        const message = welcomeMessages[Math.floor(Math.random() * welcomeMessages.length)];
        this.displayResponse(message);
        this.speakResponse(message, 'en');
    }

    createLanguageSelector() {
        const languageSelector = document.createElement('div');
        languageSelector.className = 'language-selector';
        languageSelector.innerHTML = `
            <select id="languageSelect" class="language-select">
                <option value="en-US">English</option>
                <option value="hi-IN">हिंदी</option>
                <option value="gu-IN">ગુજરાતી</option>
            </select>
        `;
        
        // Insert after the status bar
        const statusBar = document.querySelector('.status-bar');
        statusBar.parentNode.insertBefore(languageSelector, statusBar.nextSibling);
        
        // Add event listener
        document.getElementById('languageSelect').addEventListener('change', (e) => {
            this.changeLanguage(e.target.value);
        });
    }

    changeLanguage(langCode) {
        this.currentLanguage = langCode;
        if (this.recognition) {
            this.recognition.lang = langCode;
        }
        
        // Update UI text based on language
        this.updateUILanguage(langCode);
    }

    updateLanguageFromDetection(detectedLang) {
        const langMap = {
            'en': 'en-US',
            'hi': 'hi-IN',
            'gu': 'gu-IN'
        };
        
        const speechLang = langMap[detectedLang];
        if (speechLang && speechLang !== this.currentLanguage) {
            this.currentLanguage = speechLang;
            document.getElementById('languageSelect').value = speechLang;
            if (this.recognition) {
                this.recognition.lang = speechLang;
            }
        }
    }

    getLanguageCode(speechLang) {
        const codeMap = {
            'en-US': 'en',
            'hi-IN': 'hi',
            'gu-IN': 'gu'
        };
        return codeMap[speechLang] || 'en';
    }

    updateUILanguage(langCode) {
        // Always use English for UI, but support multilingual input
        const texts = {
            voicePlaceholder: 'Type your command or say "Hey JARVIS" (English/Hindi/Gujarati)...',
            listenBtn: 'Voice Command',
            sendBtn: 'Send',
            status: 'Listening for "Hey JARVIS"'
        };
        
        if (this.voiceInput) {
            this.voiceInput.placeholder = texts.voicePlaceholder;
        }
        
        if (!this.isListening && this.listenBtn) {
            this.listenBtn.innerHTML = `<i class="fas fa-microphone"></i> ${texts.listenBtn}`;
        }
        
        if (this.sendBtn) {
            this.sendBtn.textContent = texts.sendBtn;
        }
        
        if (this.isWakeWordListening) {
            this.updateStatus(texts.status, 'ready');
        }
    }

    createWakeWordToggle() {
        const wakeWordToggle = document.createElement('div');
        wakeWordToggle.className = 'wake-word-toggle';
        wakeWordToggle.innerHTML = `
            <label class="toggle-switch">
                <input type="checkbox" id="wakeWordToggle" checked>
                <span class="toggle-slider"></span>
                <span class="toggle-label">Wake Word</span>
            </label>
        `;
        
        // Insert after the language selector
        const languageSelector = document.querySelector('.language-selector');
        languageSelector.parentNode.insertBefore(wakeWordToggle, languageSelector.nextSibling);
        
        // Add event listener
        document.getElementById('wakeWordToggle').addEventListener('change', (e) => {
            if (e.target.checked) {
                this.startWakeWordListening();
            } else {
                this.stopWakeWordListening();
                this.updateStatus('Wake word disabled', 'ready');
            }
        });
    }

    createHolographicEffects() {
        // Create holographic particles
        this.createHolographicParticles();
        
        // Initialize arc reactor interactions
        this.initializeArcReactor();
        
        // Create scanning effects
        this.createScanningEffects();
    }

    createHolographicParticles() {
        const particlesContainer = document.getElementById('holoParticles');
        if (!particlesContainer) return;
        
        setInterval(() => {
            if (Math.random() < 0.3) {
                const particle = document.createElement('div');
                particle.className = 'holo-particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDuration = (Math.random() * 5 + 5) + 's';
                particle.style.animationDelay = Math.random() * 2 + 's';
                
                particlesContainer.appendChild(particle);
                
                setTimeout(() => {
                    if (particle.parentNode) {
                        particle.parentNode.removeChild(particle);
                    }
                }, 10000);
            }
        }, 200);
    }

    initializeArcReactor() {
        const arcReactor = document.getElementById('arcReactor');
        if (arcReactor) {
            arcReactor.addEventListener('click', () => {
                this.activateJarvis();
            });
            
            arcReactor.addEventListener('mouseenter', () => {
                this.playHoverSound();
            });
        }
    }

    createScanningEffects() {
        // Add scanning lines to panels
        const panels = document.querySelectorAll('.holo-panel');
        panels.forEach(panel => {
            const scanLine = document.createElement('div');
            scanLine.style.position = 'absolute';
            scanLine.style.top = '0';
            scanLine.style.left = '-100%';
            scanLine.style.width = '100%';
            scanLine.style.height = '2px';
            scanLine.style.background = 'linear-gradient(90deg, transparent, #00ffff, transparent)';
            scanLine.style.animation = 'scanLine 3s linear infinite';
            panel.style.position = 'relative';
            panel.appendChild(scanLine);
        });
    }

    createAdvancedFeatures() {
        // Add command history
        this.createCommandHistory();
        
        // Add voice spectrum visualizer
        this.createVoiceSpectrum();
        
        // Add notification system
        this.createNotificationSystem();
        
        // Add photo capture functionality
        this.initializePhotoCapture();
    }

    initializePhotoCapture() {
        // Main photo capture button
        const photoCaptureBtn = document.getElementById('photoCaptureBtn');
        if (photoCaptureBtn) {
            photoCaptureBtn.addEventListener('click', () => {
                this.capturePhoto();
            });
        }
    }

    async takeScreenshot() {
        try {
            this.showNotification('Screenshot', 'Taking screenshot...', 2000);
            this.updateStatus('Taking screenshot...', 'processing');
            
            const response = await fetch('/api/take-screenshot', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                this.showNotification('Screenshot Taken', data.message, 4000);
                this.displayResponse(data.message);
                this.speakResponse(data.message);
                this.updateStatus('Screenshot captured successfully', 'ready');
                
                // Visual feedback
                this.flashScreenshotEffect();
            } else {
                this.showNotification('Screenshot Failed', data.message, 4000);
                this.displayResponse(data.message);
                this.updateStatus('Screenshot failed', 'error');
            }
        } catch (error) {
            console.error('Screenshot error:', error);
            const errorMsg = 'Failed to take screenshot. Please check permissions.';
            this.showNotification('Error', errorMsg, 4000);
            this.displayResponse(errorMsg);
            this.updateStatus('Error', 'error');
        }
    }

    flashScreenshotEffect() {
        // Create screenshot flash effect
        const flash = document.createElement('div');
        flash.style.position = 'fixed';
        flash.style.top = '0';
        flash.style.left = '0';
        flash.style.width = '100%';
        flash.style.height = '100%';
        flash.style.background = 'rgba(0, 255, 255, 0.3)';
        flash.style.opacity = '0';
        flash.style.zIndex = '9999';
        flash.style.pointerEvents = 'none';
        flash.style.transition = 'opacity 0.2s ease';
        
        document.body.appendChild(flash);
        
        // Flash effect
        setTimeout(() => {
            flash.style.opacity = '1';
        }, 10);
        
        setTimeout(() => {
            flash.style.opacity = '0';
        }, 200);
        
        setTimeout(() => {
            if (flash.parentNode) {
                flash.parentNode.removeChild(flash);
            }
        }, 400);
        
        // Screenshot sound
        this.playScreenshotSound();
    }

    playScreenshotSound() {
        // Create screenshot sound
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(1000, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(500, audioContext.currentTime + 0.15);
        
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.15);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.15);
    }

    async capturePhoto() {
        try {
            this.showNotification('Photo Capture', 'Initializing camera...', 2000);
            this.updateStatus('Capturing photo...', 'processing');
            
            const response = await fetch('/api/capture-photo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                this.showNotification('Photo Captured', data.message, 4000);
                this.displayResponse(data.message);
                this.speakResponse(data.message);
                this.updateStatus('Photo captured successfully', 'ready');
                
                // Visual feedback
                this.flashPhotoEffect();
            } else {
                this.showNotification('Capture Failed', data.message, 4000);
                this.displayResponse(data.message);
                this.updateStatus('Photo capture failed', 'error');
            }
        } catch (error) {
            console.error('Photo capture error:', error);
            const errorMsg = 'Failed to capture photo. Please check camera permissions.';
            this.showNotification('Error', errorMsg, 4000);
            this.displayResponse(errorMsg);
            this.updateStatus('Error', 'error');
        }
    }

    flashPhotoEffect() {
        // Create camera flash effect
        const flash = document.createElement('div');
        flash.style.position = 'fixed';
        flash.style.top = '0';
        flash.style.left = '0';
        flash.style.width = '100%';
        flash.style.height = '100%';
        flash.style.background = '#ffffff';
        flash.style.opacity = '0';
        flash.style.zIndex = '9999';
        flash.style.pointerEvents = 'none';
        flash.style.transition = 'opacity 0.1s ease';
        
        document.body.appendChild(flash);
        
        // Flash effect
        setTimeout(() => {
            flash.style.opacity = '0.8';
        }, 10);
        
        setTimeout(() => {
            flash.style.opacity = '0';
        }, 150);
        
        setTimeout(() => {
            if (flash.parentNode) {
                flash.parentNode.removeChild(flash);
            }
        }, 300);
        
        // Camera shutter sound
        this.playCameraSound();
    }

    playCameraSound() {
        // Create camera shutter sound
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(200, audioContext.currentTime + 0.1);
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.1);
    }

    startSystemMonitoring() {
        // Update system status in holographic panels
        setInterval(() => {
            this.updateSystemPanels();
        }, 5000);
    }

    updateSystemPanels() {
        // Update CPU usage (simulated)
        const cpuUsage = document.getElementById('cpuUsage');
        if (cpuUsage) {
            cpuUsage.textContent = (Math.random() * 50 + 20).toFixed(1);
        }
        
        // Update memory usage (simulated)
        const memUsage = document.getElementById('memUsage');
        if (memUsage) {
            memUsage.textContent = (Math.random() * 30 + 60).toFixed(1);
        }
        
        // Update recent activity
        const recentActivity = document.getElementById('recentActivity');
        if (recentActivity && this.commandHistory && this.commandHistory.length > 0) {
            recentActivity.textContent = this.commandHistory[0].command.substring(0, 30) + '...';
        }
    }

    playStartupSequence() {
        // Play JARVIS startup sequence
        setTimeout(() => {
            const greeting = this.getTimeBasedGreeting();
            this.displayResponse(`${greeting}, sir. J.A.R.V.I.S. is online and ready to assist. All systems operational.`);
            this.speakResponse(`${greeting}, sir. JARVIS is online and ready to assist. All systems operational.`);
        }, 1000);
        
        // Startup sound
        this.playStartupSound();
    }

    getTimeBasedGreeting() {
        const now = new Date();
        const hour = now.getHours();
        
        if (hour >= 5 && hour < 12) {
            return "Good morning";
        } else if (hour >= 12 && hour < 17) {
            return "Good afternoon";
        } else if (hour >= 17 && hour < 21) {
            return "Good evening";
        } else {
            return "Good night";
        }
    }

    activateJarvis() {
        // Arc reactor activation effect
        const arcReactor = document.getElementById('arcReactor');
        if (arcReactor) {
            arcReactor.classList.add('listening-pulse');
            setTimeout(() => {
                arcReactor.classList.remove('listening-pulse');
            }, 2000);
        }
        
        this.playActivationSound();
        this.showWelcomeMessage();
    }

    playHoverSound() {
        // Subtle hover sound
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.setValueAtTime(600, audioContext.currentTime);
        
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.2);
    }

    createCommandHistory() {
        const historyContainer = document.createElement('div');
        historyContainer.className = 'command-history';
        historyContainer.innerHTML = `
            <h3 style="color: var(--primary-cyan); margin-bottom: 10px; font-family: 'Orbitron', monospace;">Command History</h3>
            <div id="historyList"></div>
        `;
        
        // Insert after response container
        const responseContainer = document.querySelector('.response-container');
        responseContainer.parentNode.insertBefore(historyContainer, responseContainer.nextSibling);
        
        this.commandHistory = [];
        this.historyList = document.getElementById('historyList');
    }

    addToHistory(command) {
        const timestamp = new Date().toLocaleTimeString();
        this.commandHistory.unshift({ command, timestamp });
        
        // Keep only last 10 commands
        if (this.commandHistory.length > 10) {
            this.commandHistory.pop();
        }
        
        this.updateHistoryDisplay();
    }

    updateHistoryDisplay() {
        this.historyList.innerHTML = '';
        this.commandHistory.forEach(item => {
            const historyItem = document.createElement('div');
            historyItem.className = 'history-item';
            historyItem.innerHTML = `
                <span class="history-command">${item.command}</span>
                <span class="history-time">${item.timestamp}</span>
            `;
            this.historyList.appendChild(historyItem);
        });
    }

    createVoiceSpectrum() {
        const spectrum = document.createElement('div');
        spectrum.className = 'voice-spectrum';
        spectrum.id = 'voiceSpectrum';
        spectrum.style.display = 'none';
        
        for (let i = 0; i < 9; i++) {
            const bar = document.createElement('div');
            bar.className = 'spectrum-bar';
            spectrum.appendChild(bar);
        }
        
        // Insert after arc reactor
        const arcReactor = document.querySelector('.arc-reactor');
        arcReactor.parentNode.insertBefore(spectrum, arcReactor.nextSibling);
    }

    showVoiceSpectrum() {
        const spectrum = document.getElementById('voiceSpectrum');
        if (spectrum) {
            spectrum.style.display = 'flex';
        }
    }

    hideVoiceSpectrum() {
        const spectrum = document.getElementById('voiceSpectrum');
        if (spectrum) {
            spectrum.style.display = 'none';
        }
    }

    createNotificationSystem() {
        this.notificationContainer = document.createElement('div');
        this.notificationContainer.id = 'notificationContainer';
        document.body.appendChild(this.notificationContainer);
    }

    showNotification(title, message, duration = 3000) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.innerHTML = `
            <div class="notification-title">${title}</div>
            <div class="notification-message">${message}</div>
        `;
        
        this.notificationContainer.appendChild(notification);
        
        // Show notification
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        // Hide and remove notification
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, duration);
    }

    createFloatingElements() {
        const container = document.createElement('div');
        container.className = 'floating-container';
        container.style.position = 'fixed';
        container.style.top = '0';
        container.style.left = '0';
        container.style.width = '100%';
        container.style.height = '100%';
        container.style.pointerEvents = 'none';
        container.style.zIndex = '-1';
        document.body.appendChild(container);
        
        setInterval(() => {
            if (Math.random() < 0.1) {
                const element = document.createElement('div');
                element.className = 'floating-element';
                element.style.left = Math.random() * 100 + '%';
                element.style.animationDuration = (Math.random() * 5 + 5) + 's';
                
                container.appendChild(element);
                
                setTimeout(() => {
                    if (element.parentNode) {
                        element.parentNode.removeChild(element);
                    }
                }, 10000);
            }
        }, 500);
    }

    createCyberGrid() {
        const grid = document.createElement('div');
        grid.className = 'cyber-grid';
        document.body.appendChild(grid);
    }

    startWakeWordListening() {
        if (this.wakeWordRecognition && !this.isWakeWordListening && !this.isListening) {
            try {
                this.isWakeWordListening = true;
                this.wakeWordRecognition.start();
                this.updateStatus('Listening for "Hey JARVIS"', 'ready');
                
                // Add subtle visual indicator
                const reactor = document.querySelector('.arc-reactor');
                reactor.classList.add('wake-word-listening');
            } catch (error) {
                console.error('Error starting wake word listening:', error);
                this.isWakeWordListening = false;
            }
        }
    }

    stopWakeWordListening() {
        if (this.wakeWordRecognition && this.isWakeWordListening) {
            this.isWakeWordListening = false;
            this.wakeWordRecognition.stop();
            
            const reactor = document.querySelector('.arc-reactor');
            reactor.classList.remove('wake-word-listening');
        }
    }

    onWakeWordDetected(transcript) {
        console.log('Wake word detected:', transcript);
        
        // Stop wake word listening
        this.stopWakeWordListening();
        
        // Visual feedback
        this.updateStatus('Wake word detected! Listening...', 'listening');
        this.addVoiceVisualization();
        
        // Play activation sound
        this.playActivationSound();
        
        // Start command listening
        setTimeout(() => {
            this.startCommandListening();
        }, 500);
    }

    startCommandListening() {
        if (this.recognition && !this.isListening) {
            try {
                this.isListening = true;
                this.recognition.start();
                this.updateStatus('Listening for command...', 'listening');
            } catch (error) {
                console.error('Error starting command listening:', error);
                this.isListening = false;
                this.startWakeWordListening();
            }
        }
    }

    playActivationSound() {
        // Create activation sound
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        // Two-tone activation sound
        oscillator.frequency.setValueAtTime(600, audioContext.currentTime);
        oscillator.frequency.setValueAtTime(800, audioContext.currentTime + 0.1);
        
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.3);
    }

    // Song Recognition Methods
    async startSongRecognition() {
        try {
            this.displayResponse("🎤 I'm ready to listen to you sing, sir! Please start singing or humming the song...");
            this.updateStatus('Listening for song...', 'listening');
            
            // Start recording for song recognition
            const response = await fetch('/api/song-recognition', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'start_recording'
                })
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                // Show recording indicator
                this.showRecordingIndicator(result.duration);
                
                // After recording, ask for lyrics
                setTimeout(() => {
                    this.displayResponse("🎵 Recording complete! Could you please tell me some lyrics from the song you just sang? For example: 'The song goes: shape of you, I'm in love with your body'");
                    this.updateStatus('Ready', 'ready');
                }, result.duration * 1000);
            } else {
                this.displayResponse(`❌ ${result.message}`);
                this.updateStatus('Error', 'error');
            }
            
        } catch (error) {
            console.error('Song recognition error:', error);
            this.displayResponse("❌ Error starting song recognition. Please try again.");
            this.updateStatus('Error', 'error');
        }
    }

    async recognizeSongFromLyrics(lyrics) {
        try {
            this.showTypingIndicator();
            this.updateStatus('Recognizing song...', 'processing');
            
            const response = await fetch('/api/song-recognition', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    action: 'recognize_lyrics',
                    lyrics: lyrics
                })
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                this.displayResponse(`🎵 Found it! That's "${result.song_title}" by ${result.artist}. Opening on YouTube now, sir.`);
                
                // Open YouTube search
                window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(result.youtube_search)}`, '_blank');
                
                this.updateStatus('Song found!', 'success');
            } else if (result.status === 'not_found') {
                this.displayResponse(`🎵 I couldn't identify the exact song, but I've searched YouTube for those lyrics to help you find it, sir.`);
                
                // Open YouTube search with lyrics
                window.open(result.youtube_search, '_blank');
                
                this.updateStatus('Searching...', 'processing');
            } else {
                this.displayResponse(`❌ ${result.message}`);
                this.updateStatus('Error', 'error');
            }
            
        } catch (error) {
            console.error('Song recognition error:', error);
            this.displayResponse("❌ Error recognizing song. Please try again.");
            this.updateStatus('Error', 'error');
        } finally {
            this.hideTypingIndicator();
        }
    }

    showRecordingIndicator(duration) {
        // Create recording indicator
        const indicator = document.createElement('div');
        indicator.className = 'recording-indicator';
        indicator.innerHTML = `
            <div class="recording-dot"></div>
            <span>Recording... ${duration}s</span>
        `;
        
        document.body.appendChild(indicator);
        
        // Countdown
        let timeLeft = duration;
        const countdown = setInterval(() => {
            timeLeft--;
            indicator.querySelector('span').textContent = `Recording... ${timeLeft}s`;
            
            if (timeLeft <= 0) {
                clearInterval(countdown);
                indicator.remove();
            }
        }, 1000);
        
        // Remove after duration
        setTimeout(() => {
            if (indicator.parentNode) {
                indicator.remove();
            }
        }, duration * 1000);
    }
}

// Additional CSS for dynamic effects
const additionalStyles = `
    .listening-pulse {
        animation: listeningPulse 0.5s ease-in-out infinite alternate !important;
    }
    
    @keyframes listeningPulse {
        from { 
            transform: scale(1);
            box-shadow: 0 0 50px var(--primary-cyan);
        }
        to { 
            transform: scale(1.1);
            box-shadow: 0 0 80px var(--primary-cyan), 0 0 120px var(--primary-cyan);
        }
    }
    
    .response-glow {
        box-shadow: 0 0 30px rgba(0, 212, 255, 0.5) !important;
        border-color: var(--primary-cyan) !important;
    }
    
    .btn.listening {
        background: linear-gradient(45deg, #ffaa00, #ff6600) !important;
        animation: buttonPulse 1s ease-in-out infinite !important;
    }
    
    @keyframes buttonPulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }
    
    .recording-indicator {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(0, 0, 0, 0.8);
        color: #00d4ff;
        padding: 20px 30px;
        border-radius: 10px;
        border: 2px solid #00d4ff;
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 10000;
        font-family: 'Orbitron', monospace;
        box-shadow: 0 0 30px rgba(0, 212, 255, 0.5);
    }
    
    .recording-dot {
        width: 12px;
        height: 12px;
        background: #ff0000;
        border-radius: 50%;
        animation: recordingPulse 1s ease-in-out infinite;
    }
    
    @keyframes recordingPulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.5; transform: scale(1.2); }
    }
    
    .language-selector {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
    }
    
    .language-select {
        background: rgba(0, 20, 40, 0.9);
        border: 1px solid var(--primary-cyan);
        border-radius: 8px;
        color: var(--primary-cyan);
        padding: 8px 12px;
        font-family: 'Orbitron', monospace;
        font-size: 12px;
        backdrop-filter: blur(10px);
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .language-select:hover {
        background: rgba(0, 212, 255, 0.1);
        box-shadow: 0 0 15px rgba(0, 212, 255, 0.3);
    }
    
    .language-select:focus {
        outline: none;
        box-shadow: 0 0 20px rgba(0, 212, 255, 0.5);
    }
    
    .language-select option {
        background: rgba(0, 20, 40, 0.95);
        color: var(--primary-cyan);
        padding: 5px;
    }
    
    .wake-word-listening {
        animation: wakeWordPulse 2s ease-in-out infinite !important;
    }
    
    @keyframes wakeWordPulse {
        0%, 100% { 
            opacity: 0.8;
            transform: scale(1);
        }
        50% { 
            opacity: 1;
            transform: scale(1.02);
            box-shadow: 0 0 30px rgba(0, 212, 255, 0.3);
        }
    }
    
    .file-operation-result {
        background: rgba(0, 212, 255, 0.1);
        border: 1px solid var(--primary-cyan);
        border-radius: 8px;
        padding: 10px;
        margin: 10px 0;
        font-family: 'Courier New', monospace;
        font-size: 12px;
    }
    
    .wake-word-toggle {
        position: fixed;
        top: 60px;
        right: 20px;
        z-index: 1000;
    }
    
    .toggle-switch {
        display: flex;
        align-items: center;
        cursor: pointer;
        font-family: 'Orbitron', monospace;
        font-size: 12px;
        color: var(--primary-cyan);
    }
    
    .toggle-switch input {
        display: none;
    }
    
    .toggle-slider {
        width: 40px;
        height: 20px;
        background: rgba(0, 20, 40, 0.9);
        border: 1px solid var(--primary-cyan);
        border-radius: 20px;
        position: relative;
        transition: all 0.3s ease;
        margin-right: 8px;
    }
    
    .toggle-slider:before {
        content: '';
        position: absolute;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background: var(--primary-cyan);
        top: 1px;
        left: 1px;
        transition: all 0.3s ease;
    }
    
    .toggle-switch input:checked + .toggle-slider {
        background: rgba(0, 212, 255, 0.2);
        box-shadow: 0 0 10px rgba(0, 212, 255, 0.3);
    }
    
    .toggle-switch input:checked + .toggle-slider:before {
        transform: translateX(20px);
        box-shadow: 0 0 5px rgba(0, 212, 255, 0.5);
    }
    
    .toggle-label {
        user-select: none;
    }
`;

// Add the additional styles to the document
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);

// Initialize JARVIS when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.jarvis = new JarvisInterface();
    
    // Add Font Awesome for icons
    const fontAwesome = document.createElement('link');
    fontAwesome.rel = 'stylesheet';
    fontAwesome.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css';
    document.head.appendChild(fontAwesome);
});